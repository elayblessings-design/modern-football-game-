# ELAY FOOTBALL — Malawi Super League

This project wraps the local HTML football game in an Android WebView app.

## App details
- Android app label: ELAY FOOTBALL
- Package ID: `mw.elayfootball`
- Landscape, immersive full-screen mode
- Local game file: `app/src/main/assets/index.html`
- No internet permission is requested; the game runs from the bundled HTML file.
- Current game prototype: 2D canvas football, Malawi Super League club selection, 11 players per side, touch joystick, pass, shoot and sprint.

## Build in GitHub Actions
1. Upload all project files to the root of your GitHub repository.
2. Open the **Actions** tab and select **Build ELAY FOOTBALL APK**.
3. If it has not run automatically, choose **Run workflow**.
4. Open the completed workflow run and download the `ELAY-FOOTBALL-debug-APK` artifact.
5. Extract the downloaded ZIP to get `app-debug.apk`.

This workflow creates a debug APK for testing. A signed release APK for Google Play is a separate later step.
